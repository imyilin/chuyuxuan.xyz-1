---
title: 日常打卡
tags: 打卡
cover: 'https://gitee.com/chuyuxuan/tuc/raw/master/Cartoon_pictures/timg%20(2).jpg'
top: true
message: 请输入密码
wrong_pass_message: 又想偷看文章内容?密码不正确不给你看哦！
wrong_hash_message: '抱歉, 这个文章不能被校验, 不过您还是能看看解密后的内容.'
password: helloworld
categories:
  - ▶生活日常
date: 2019-12-12 14:55:31
---






## 2020-5-4 
{% note danger %}
+ 噢！天哪，我最近在干些啥？只是在记单词感觉没啥用啊！
+ 你现在是在准备考研啊，要在5月份结束前把数一过一遍！
{% endnote %}


## 2020-4-13 00 至 2020-4-13023：00
{% note danger %}
+ 高数第二章知识巩固
+ JavaScript框架构建
{% endnote %}
{% note success %}
+ 单词记忆 √
{% endnote %}


## 2020-4-12 00：00 至 2020-4-12 23：00
{% note danger %}
+ 高数第一章知识巩固 ×
+ JavaScript框架构建 ×
{% endnote %}
{% note success %}
+ 单词记忆 √
{% endnote %}
## 2020-4-1 至 2020-4-5标准
{% note success %}
单词记忆 √
{% endnote %}
{% note danger %}
vue框架构建 ×
{% endnote %}
## 加油！


---
title: 我离开了Atom
tags:
  - Atom
  - 卸载
cover: 'https://gitee.com/chuyuxuan/tuc/raw/master/daily/atom.png'
categories:
  - ▶生活日常
date: 2020-02-12 22:00:00
---
# 是时候说再见了
是的，从学习前端开始，我几乎都在使用atom。`hello world`的第一行JavaScript代码是用它编写的。那个时候的我贼兴奋，因为我能够做一些自己高中想的事情了，比方说下载歌曲(~~白嫖~~)。弄得到一首自己喜欢的歌兴奋半天。
# 觉得我很会扯
{% note danger %}
好吧，扯的优点远了，其实是我的Atom `preview-plus`插件完全死机。我**重装**→**卸载**→**重装**，删除环境变量，`npm`等等，还是不行。真的，让我有点无奈，虽然不用预览，我也可以写`MarkDown`但是，随叫我有强迫症，不喜欢。🤣
{% endnote %}
诺，`Atom`我为你留下一张照片哈哈哈：
![](https://gitee.com/chuyuxuan/tuc/raw/master/daily/atom2.png)
# 我要得到~~新欢~~
其实，`VsCode`在我电脑里待了很久了，之前用它配置了`C++`环境，主要是我自己不想用太多的IDE。为什么不把大部分都集中到一起来呢？`VsCode`就成为了我的一个实验品![](https://gitee.com/chuyuxuan/tuc/raw/master/laugh/053.gif)。最后，由于`Atom`的~~失误~~，完美过度到`VScode`上来了，😂
附上这篇文章的编辑界面（小声逼逼.jpg）
![](https://gitee.com/chuyuxuan/tuc/raw/master/daily/atom3.png)
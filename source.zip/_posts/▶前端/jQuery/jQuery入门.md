---
title: 关于的jQuery小知识以及碎碎念
tags:
  - jQuery
cover: 'https://gitee.com/chuyuxuan/tuc/raw/master/jQuery/cover.png'
categories:
  - ▶前端
date: 2020-04-06 21:00:00
---

# 碎碎念
是的，很多人认为`jQuery`并不是一个好用的框架，像什么`Vue`啊，`React`啊，`Angular`啊，这些才算的上一个高大上的框架。但是，存在还是有一定的道理的，就像是没有jQuery这样的简化JavaScript的框架，当作`前浪`，vue等后面框架的面世，还是需要一点变革的。

`那么我为什么会开始学习jQuery？`这个问题问得好，因为学校要求学🤣。就像学校现在还要求我们学习在现在的互联网公司不会用的{% hint '过时了' '主要是现在有更好的框架去代替，而且效率还高。' %}的`jsp`一样。嘛~，我这不是抱怨，算是一种考古哈哈。就比如说哪一天，突然间出现了一个十分强大的前端框架，直接把我上面刚刚所说的架构全部给代替了，那么我们现在所学的，所认为的前沿框架在那个时候的人看来，不也是过时之物么？技术永远是在发展的，这里呢，我就抱着一颗虔诚之心🧡，好好的把学校里安排的知识给稍微美化整理一下。那么，开始嘻嘻！
=================我是分界线==============

# jQuery入门

## 1. 环境安装
安装环境是使用`jQuery`的第一步，如果你需要在本地运行jQuery，可以查看[官网](https://jquery.com/)来安装jQuery库。这里推荐使用官方定制的CDN进行引入，当然，这在网上是可以搜寻到的。

## 2. 第一个程序
在`<div id="box"></div>`里填充内容`hello,jquery`。实现的效果。
![1](https://gitee.com/chuyuxuan/tuc/raw/master/jQuery/image001.gif)

这里用`javascript`先实现一下：
```js
var box = document.getElementById("box");
box.innerHTML = "hello,jquery";
```
用`jQuery`实现会更简单，下面每一步都和上面的相对应，实现如下：
```js
var box = $("#box");
box.html("hello,jquery");
```
从上面可以看出：
+ `$("#box")`是获取到`id="box"`的`div`

+ `html()`方法是获取元素的内容（包括HTML标记）， `()`里面没有内容表示获取，有内容表示赋值。

基本语法：
    
     $(selector).action()

说明:
+	`jQuery`用美元符号` $ `定义；
+	`selector`表示要操作的`dom`元素； 
+ 	`action`表示要执行的操作。


## 3. 基本选择器
和`CSS`一样，`jQuery`也有基本选择器，我们先来看一下源码：
```js
<div id="box1">我是id选择器</div>
<p class="box2"></p>
<span></span>

```
### id选择器
对于上面 `id="box1"`的` div`，用`jquery`实现如下：
```js
	var box1 = $("#box1");
	box1.html();
```
效果如下（下面div获取上面div的内容）：
![2](https://gitee.com/chuyuxuan/tuc/raw/master/jQuery/image003.gif)
从上面可以看出，id选择器语法： 
    
    $("# + idName")
    
这里再提醒一下：
`html()：`里的 `()`里有内容，表示往该元素添加内容，没有内容，表示获取内容。
### 类选择器
对于上面` class="box2"`的 `p`， 用`jQuery` 实现如下：
```js
	var box2 = $(".box2");
	box2.html("我是类选择器");
```

效果如下：
![3](https://gitee.com/chuyuxuan/tuc/raw/master/jQuery/image004.gif)
从上面可以看出,类选择器语法：

    $(". + className")

### 元素选择器
对于上面 `<span></span>`， 用`jQuery`实现如下：
```js
	var box3 = $("span");
	box3.html("我是元素选择器");
```
效果如下：
![4](https://gitee.com/chuyuxuan/tuc/raw/master/jQuery/image005.gif)

从上面可以看出,元素选择器语法：

    $("tagName")

### 过滤选择器(重点)
例如，现有代码如下：
```html
<ul>
    <li>第一个li</li>
	<li>第二个li</li>
	<li>第三个li</li>
    <li>第四个li</li>
    <li>第五个li</li>
	<li>第六个li</li>
</ul>
```
基础效果图如下：
![](https://gitee.com/chuyuxuan/tuc/raw/master/jQuery/image010.png)

现在分别获取获取指定的`li`元素，并添加相应的背景色。
    
+ 获取**第一个**`li`标签，添加背景色`orange`：
```js
$("li:first").css("background","orange")
``` 
+ 获取最**后一个**`li`标签，添加背景色`green` :
```js
$("li:last").css("background","green")；
``` 
效果图如下：

![](https://gitee.com/chuyuxuan/tuc/raw/master/jQuery/image012.png)

- 获取下标为`偶数`的li标签，添加背景色`#ccc`：
```js
$("li:even").css("background","#eee");
```
+ 获取下标为`奇数`的li标签，添加背景色`#ccc`:
```js
$("li:odd").css("background","#ccc");
```
效果图如下：

![](https://gitee.com/chuyuxuan/tuc/raw/master/jQuery/image014.png)


**注：下标是从0开始的，li标签第一个下标是0，是偶数，所以背景色是"#eee"。**


#### `:eq`选择器

+ 获取指定序号的元素
例如，现有一下代码：

```html
	 <ul>
	        <li>第一个li</li>
	        <li>第二个li</li>
	        <li>第三个li</li>
	 </ul>
```

![](https://gitee.com/chuyuxuan/tuc/raw/master/jQuery/image019.png)

实现`第二个li标签`背景色为红色.
```js
$("li:eq(1)").css("background","red");

//或者

$("li").eq(1).css("background","red");

 //eq 选择器的下标是从0开始
```
![](https://gitee.com/chuyuxuan/tuc/raw/master/jQuery/image021.png)



#### :not选择器

倘若我们要实现这样的效果：

![](https://gitee.com/chuyuxuan/tuc/raw/master/jQuery/image025.png)

第`四个li标签`的右侧`没有外边距`,`not选择器`，它选取`除了指定元素以外`的所有元素:
```js
$("li:not(:last)").css("margin-right","20px");
```
效果如下：

![](https://gitee.com/chuyuxuan/tuc/raw/master/jQuery/image026.png)



### 层次选择器
有如下代码：
```html
	<div class="container">
	    <p>
	       <span>第一个p标签下的span</span>
	       <span>第一个p标签下的第二个span</span>
	    </p>
	    <p>
	       <i>i标签</i>
	       <span>第二个p标签下的span</span>
	    </p>
	</div>
```
若想要获取到上面`第一个p标签`下所有的`span`标签,可以按照以下步骤：

1. 获取到类*container*：`$(".container");`

2. 获取到*container*下第一个*p*标签：`$(".container p:first");`

3. 获取到第一个p标签下所有的*span*标签：`$(".container p:first span")`。

**层次选择器和Dom结构是相匹配的.**

### show()与hide()

有如下代码：
```html
	<p class="toggle">错误提醒</p>
	<p>展示的内容</p>
```
对于`类toggle`，有错误时需要出现，解决了错误需要隐藏。

+ 	出现：$(".toggle").show()

    相当于css中的` display:block;`

+ 	隐藏：$(".toggle").hide()

    相当于css中的 `display:none;`

### 类的添加和删除
有如下代码：
```js
	<div id="box"></div>
    //假如要给div添加类active和btn
    active{ background: orange;}
	btn{}
```
假如要给div添加类`active`和`btn`,这里用`addClass()`方法：
```js
$("#box").addClass("active btn");
```
现在要删除一个类btn，这里用removeClass()方法：
```js
$("#box").removeClass("btn");
````

## 4. 设置css属性

### 设置单个属性
```js
<div id="single">设置单个属性</div>
```
如果给上面的`div`标签添加`css`属性：`background：orange;`对于`div`标签，用jQuery可以这样写：
```js
$("#single").css("background","orange");
```
效果如下：

![4](https://gitee.com/chuyuxuan/tuc/raw/master/jQuery/image008.gif)

这是设置单个属性常用的方法。语法总结如下：

    $(selector).css(attr,value);

### 设置多个属性
```js
<p class="more">设置多个属性</p>
```
如果给上面的`p`标签添加`css`属性：

```css
	"background":"#ccc";
	"text-align":"center";
	"line-height":"40px";
```
对于`p`标签，用上面的方法一条一条的写，也是可以的，但是比较麻烦，下面是设置多个css属性的方法：
```js
	$(".more").css({
	"background":"#ccc",
	"text-align":"center",
	"line-height":"40px"
	})
```
效果如下：

![5](https://gitee.com/chuyuxuan/tuc/raw/master/jQuery/image009.gif)

可以看出，设置多个css属性是用对象的方式来实现的。语法总结如下:

    $(selector).css({
	attr1: value1,
	attr2: value2,
	...
	})



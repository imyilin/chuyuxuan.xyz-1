---
title: 全屏预览插件及其属性
tags:
  - jQuery
  - fullpage
cover: 'https://s1.ax1x.com/2020/04/12/GOOsPI.gif'
categories:
  - ▶前端
date: 2020-04-12 21:00:00
---
# 算得上是前言
<font color="#0ff">~~*再不开学我要被家里人嫌弃死了。*🤣~~</font>

无意间闲逛`iPhone11`的[官网](https://www.apple.com.cn/iphone-11-pro/)时，~~当然是闲的蛋疼~~ 被它的宣传广告给深深吸引。全程我震惊不断：卧槽，这个动画可以这样玩？欸？！视频直接进入动画了？！6666！

![](https://gitee.com/chuyuxuan/tuc/raw/master/laugh/amazing.png)
不得不感叹苹果不愧是业界大佬，钦佩钦佩。我只会~~面向GitHub编程~~。这不，最近几天在研究`jQuery`，突然就搜到了这个全屏滚动插件，效果是真的棒！我表示很喜欢！感谢作者！！

![](https://gitee.com/chuyuxuan/tuc/raw/master/jQuery/20200412.gif)



# 使用方法

1.正如上图所示，可以实现全屏滚动，这个视觉冲击可以说是杠杠的，我们只需要到GitHub上clone仓库即可。

仓库地址：[点我访问](https://github.com/alvarotrigo/fullPage.js)

![](https://s1.ax1x.com/2020/04/12/GOOsPI.gif)

2.把`dist`里的文件分别按`js`,`css`分类放置到你的项目文件中。
![](https://gitee.com/chuyuxuan/tuc/raw/master/jQuery/202004121.jpg)

![](https://gitee.com/chuyuxuan/tuc/raw/master/jQuery/202004122.jpg)

3.在`html`文件中引入以下代码即可食用啦！

![](https://gitee.com/chuyuxuan/tuc/raw/master/laugh/watermaleon.png)


# 官方介绍

国内演示地址：[点我访问](https://www.dowebok.com/demo/2014/77/)

## fullPage.js 是一个基于 jQuery 的插件，它能够很方便、很轻松的制作出全屏网站，主要功能有：
+ 支持鼠标滚动
+ 支持前进后退和键盘控制
+ 多个回调函数
+ 支持手机、平板触摸事件
+ 支持 CSS3 动画
+ 支持窗口缩放
+ 窗口缩放时自动调整
+ 可设置滚动宽度、背景颜色、滚动速度、循环选项、回调、文本对齐方式等等


## 兼容性
兼容 jQuery 1.7+。
### 浏览器兼容
|IE|	Chrome|	Firefox	|Opera|	Safari|
|:-:|:-:|:-:|:-:|:-:|
|IE8+ ✔	|Chrome ✔	|Firefox ✔	|Opera ✔	|Safari ✔|

## 引入文件
```html
<link rel="stylesheet" href="css/jquery.fullPage.css">
<script src="js/jquery.min.js"></script>

<!-- jquery.easings.min.js 用于 easing 参数，也可以使用完整的 jQuery UI 代替，如果不需要设置 easing 参数，可去掉改文件 -->
<script src="js/jquery.easings.min.js"></script>

<!-- 如果 scrollOverflow 设置为 true，则需要引入 jquery.slimscroll.min.js，一般情况下不需要 -->
<script src="js/jquery.slimscroll.min.js"></script>

<script src="js/jquery.fullPage.js"></script>

```
### html

```html
<div id="dowebok">
    <div class="section">
        <h3>第一屏</h3>
    </div>
    <div class="section">
        <h3>第二屏</h3>
    </div>
    <div class="section">
        <h3>第三屏</h3>
    </div>
    <div class="section">
        <h3>第四屏</h3>
    </div>
</div>
```
每个` section `代表一屏，默认显示`“第一屏”`，如果要指定加载页面时显示的`“屏幕”`，可以在对应的 `section `加上 `class=”active”`，如：

    <div class="section active">第三屏</div>

同时，可以在` section` 内加入 `slide`，如：

```html
<div id="dowebok">
    <div class="section">第一屏</div>
    <div class="section">第二屏</div>
    <div class="section">
        <div class="slide">第三屏的第一屏</div>
        <div class="slide">第三屏的第二屏</div>
        <div class="slide">第三屏的第三屏</div>
        <div class="slide">第三屏的第四屏</div>
    </div>
    <div class="section">第四屏</div>
</div>
```
### JavaScript

```js
$(function(){
    $('#dowebok').fullpage();
});
```

## 配置
### 选项
|选项|	类型|	默认值|	说明|
|:-:|:-:|:-:|:-:|
|verticalCentered|	字符串|	true	|内容是否垂直居中|
|resize	|布尔值|	false	|字体是否随着窗口缩放而缩放|
|slidesColor	|函数|	无|	设置背景颜色|
|anchors|	数组|	无|	定义锚链接|
|scrollingSpeed|	整数|	700|	滚动速度，单位为毫秒|
|easing	|字符串|	|easeInQuart	滚动动画方式|
|menu	|布尔值|	false|	绑定菜单，设定的相关属性与 anchors 的值对应后，菜单可以控制滚动|
|navigation	|布尔值	|false|	是否显示项目导航|
|navigationPosition	|字符串|	right	|项目导航的位置，可选 left 或 right|
|navigationColor	|字符串	|#000|	项目导航的颜色|
|navigationTooltips|	数组|	空|	项目导航的 tip|
|slidesNavigation	|布尔值|	false	|是否显示左右滑块的项目导航|
|slidesNavPosition	|字符串|	bottom|	左右滑块的项目导航的位置，可选 top 或 bottom|
|controlArrowColor	|字符串|	#fff|	左右滑块的箭头的背景颜色|
|loopBottom	|布尔值	|false|	滚动到最底部后是否滚回顶部|
|loopTop|	布尔值	|false|	滚动到最顶部后是否滚底部|
|loopHorizontal	|布尔值	|true|	左右滑块是否循环滑动|
|autoScrolling	|布尔值|	true|	是否使用插件的滚动方式，如果选择 false，则会出现浏览器自带的滚动条、
|scrollOverflow	|布尔值	|false	|内容超过满屏后是否显示滚动条|
|css3	|布尔值|	false	|是否使用 CSS3 transforms 滚动|
|paddingTop	|字符串	|0|	与顶部的距离|
|paddingBottom|	字符串|	0	|与底部距离|
|fixedElements|	字符串|	无	|
|normalScrollElements	|	无	|
|keyboardScrolling|	布尔值|	true|	是否使用键盘方向键导航|
|touchSensitivity	|整数|	5	||
|continuousVertical	|布尔值|	false	|是否循环滚动，与 loopTop 及 loopBottom 不兼容|
|animateAnchor|	布尔值|	true	||
|normalScrollElementTouchThreshold|	整数|	5	||
### 方法

名称|	说明
|:-:|:-:|
moveSectionUp()	|向上滚动|
moveSectionDown()|	向下滚动|
moveTo(section, slide)|	滚动到|
moveSlideRight()|slide向右滚动|
moveSlideLeft()|	slide 向左滚动|
setAutoScrolling()	|设置页面滚动方式，设置为 true 时自动滚动|
setAllowScrolling()|	添加或删除鼠标滚轮/触控板控制|
setKeyboardScrolling()	|添加或删除键盘方向键控制|
setScrollingSpeed()|	定义以毫秒为单位的滚动速度|


### 回调函数
名称|	说明
|:-:|:-:|
afterLoad	|滚动到某一屏后的回调函数，接收 anchorLink 和 index 两个参数，anchorLink 是锚链接的名称，index 是序号，从1开始计算|
onLeave	|滚动前的回调函数，接收 index、nextIndex 和 direction 3个参数：index 是离开的“页面”的序号，从1开始计算；|
nextIndex |是滚动到的“页面”的序号，从1开始计算；|
|direction |判断往上滚动还是往下滚动，值是 up 或 down。|
|afterRender|页面结构生成后的回调函数，或者说页面初始化完成后的回调函数
|afterSlideLoad|	滚动到某一水平滑块后的回调函数，与 afterLoad 类似，接收 anchorLink、index、slideIndex、direction 4个参数|
|onSlideLeave|某一水平滑块滚动前的回调函数，与 onLeave 类似，接收 anchorLink、index、slideIndex、direction 4个参数|
---
title: CSS-list相关
tags:
  - 前端
  - CSS
  - list
cover: 'https://gitee.com/chuyuxuan/tuc/raw/master/CSS/1.png'
categories:
  - ▶前端
date: 2020-02-11 19:49:35
---

# 所有的CSS列表属性

| 属性                  | 描述                        |
| :------------------ | :------------------------ |
| list-style          | 简写属性。用于把所有用于列表的属性设置于一个声明中 |
| list-style-image    | 将图象设置为列表项标志。              |
| list-style-position | 设置列表中列表项标志的位置。            |
| list-style-type     | 设置列表项标志的类型。               |

# 列表

在HTML中，有两种类型的列表：

-   无序列表 - 列表项标记用特殊图形（如小黑点、小方框等）
-   有序列表 - 列表项的标记有数字或字母
-   使用CSS，可以列出进一步的样式，并可用图像作列表项标记。

例如：

```html
<html>
<head>
<meta charset="utf-8">
<title></title>
<style>
ul.a {list-style-type:circle;}
ul.b {list-style-type:square;}
ol.c {list-style-type:upper-roman;}
ol.d {list-style-type:lower-alpha;}
</style>
</head>

<body>
<p>无序列表实例:</p>

<ul class="a">
  <li>Coffee</li>
  <li>Tea</li>
  <li>Coca Cola</li>
</ul>

<ul class="b">
  <li>Coffee</li>
  <li>Tea</li>
  <li>Coca Cola</li>
</ul>

<p>有序列表实例:</p>

<ol class="c">
  <li>Coffee</li>
  <li>Tea</li>
  <li>Coca Cola</li>
</ol>

<ol class="d">
  <li>Coffee</li>
  <li>Tea</li>
  <li>Coca Cola</li>
</ol>

</body>
</html>
```
结果如下：
![](https://gitee.com/chuyuxuan/tuc/raw/master/CSS/list-1.png')

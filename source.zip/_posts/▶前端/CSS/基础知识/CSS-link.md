---
title: CSS链接相关
tags:
  - 前端
  - CSS
  - link
cover: 'https://gitee.com/chuyuxuan/tuc/raw/master/CSS/1.png'
categories:
  - ▶前端
date: 2020-02-11 18:49:35
---

## 链接样式

链接的样式，可以用任何CSS属性（如颜色，字体，背景等）。特别的链接，可以有不同的样式，这取决于他们是什么状态。

这四个链接状态是：
{% note success %}

-   `a:link`- 正常，未访问过的链接
-   `a:visited` - 用户已访问过的链接
-   `a:hover` - 当用户鼠标放在链接上时
-   `a:active`- 链接被点击的那一刻
    {% endnote %}
    就像这样：
    ![](https://gitee.com/chuyuxuan/tuc/raw/master/record_gif/css1.gif)

{% note danger %}
当设置为若干链路状态的样式，也有一些顺序规则：

-   `a:hover` 必须跟在 a:link 和 a:visited后面
-   `a:active`必须跟在 a:hover后面
{% endnote %}
    z这里就拿一个`文本修饰`来演示一下：
    ![](https://gitee.com/chuyuxuan/tuc/raw/master/record_gif/css2.gif)

```html
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title></title>
<style>
a.one:link {color:#ff0000;}
a.one:visited {color:#0000ff;}
a.one:hover {color:#ffcc00;}

a.two:link {color:#ff0000;}
a.two:visited {color:#0000ff;}
a.two:hover {font-size:150%;}

a.three:link {color:#ff0000;}
a.three:visited {color:#0000ff;}
a.three:hover {background:#66ff66;}

a.four:link {color:#ff0000;}
a.four:visited {color:#0000ff;}
a.four:hover {font-family:Georgia, serif;}

a.five:link {color:#ff0000;text-decoration:none;}
a.five:visited {color:#0000ff;text-decoration:none;}
a.five:hover {text-decoration:overline;}
	body{

	background: #fffff3;
	}
	</style>
</head>

<body>
<p>将鼠标移至链接上改变样式.</p>

<p><b><a class="one" href="/css/"  target="_blank">这个链接改变颜色</a></b></p>
<p><b><a class="two" href="/css/" target="_blank">这个链接改变字体大小</a></b></p>
<p><b><a class="three" href="/css/" target="_blank">这个链接改变背景颜色</a></b></p>
<p><b><a class="four" href="/css/" target="_blank">这个链接改变字体类型</a></b></p>
<p><b><a class="five" href="/css/" target="_blank">这个链接改变文字修饰</a></b></p>
</body>

</html>
```

![](https://gitee.com/chuyuxuan/tuc/raw/master/record_gif/css3.gif)

---
title: CSS-Text相关
tags:
  - 前端
  - CSS
  - text
cover: 'https://gitee.com/chuyuxuan/tuc/raw/master/CSS/1.png'
categories:
  - ▶前端
date: 2020-02-11 12:49:35
---
# 所有CSS-Text属性
|属性	|描述|
|:-|:-|
|[color](#color)|	设置文本颜色|
|direction	|设置文本方向。|
|letter-spacing|	设置字符间距|
|line-height|	设置行高|
|text-align	|对齐元素中的文本|
|[text-decoration](#text-decoration)|向文本添加修饰|
|text-indent|	缩进元素中文本的首行|
|text-shadow|	设置文本阴影|
|text-transform	|控制元素中的字母|
|unicode-bidi	|设置或返回文本是否被重写 |
|vertical-align	|设置元素的垂直对齐|
|white-space	|设置元素中空白的处理方式|
|word-spacing|	设置字间距|

## <a id="color">文本颜色[color]</a>
+ 设置字体颜色就`color`,不要加一个`text-color`。
```CSS
body {color:red;}
h1 {color:#00ff00;}
h2 {color:rgb(255,0,0);}
```
效果如下：

![](https://gitee.com/chuyuxuan/tuc/raw/master/CSS/text-1.png)

<font size = 2 color = red >W3C标准的CSS：如果定义了颜色属性，还必须定义背景色属性。当然，知道的人不多罢了。</font>![](https://gitee.com/chuyuxuan/tuc/raw/master/laugh/007.gif)




## 对齐方式[text-align]
+ 设置文本的水平对齐方式。
文本可居中或对齐到左或右,两端对齐.
当`text-align`设置为`justify`，每一行被展开为宽度相等，左，右外边距是对齐（如杂志和报纸）
```CSS
h1 {text-align:center;}
p.date {text-align:right;}
p.main {text-align:justify;}
```
效果如下：

![](https://gitee.com/chuyuxuan/tuc/raw/master/CSS/text-2.png)

##  <a id="text-decoration">文本修饰[text-decoration]</a>

+ 用来设置或删除文本的装饰。`text-decoration`属性主要是用来删除链接的下划线:
```css
 a {text-decoration:none;}
```
+ 也可以这样装饰文字：
```CSS
h1 {text-decoration:overline;}
h2 {text-decoration:line-through;}
h3 {text-decoration:underline;}
```
效果如下：

![](https://gitee.com/chuyuxuan/tuc/raw/master/CSS/text-3.png)


## 文本转换
- 文本转换属性是用来指定在一个文本中的大写和小写字母。可用于所有字句变成大写或小写字母，或每个单词的首字母大写。

```CSS
p.uppercase {text-transform:uppercase;}
p.lowercase {text-transform:lowercase;}
p.capitalize {text-transform:capitalize;}
```
效果如下：

![](https://gitee.com/chuyuxuan/tuc/raw/master/CSS/text-4.png)

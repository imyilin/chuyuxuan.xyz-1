---
title: javascript正则表达式
tags: javaScript
cover: >-
  https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1580367149122&di=deafe93ce2f987df33a87a34c8e685dc&imgtype=0&src=http%3A%2F%2Fstatic.hxrwx.com%2Fupload%2Fmavendemo%2Fcourse%2F20160125%2F1453687219607216305.jpg
categories:
  - ▶前端
date: 2020-01-30 12:48:29
---
# js正则表达式
+ 正则表达式是构成 **搜索模式（search pattern** 的字符序列。
+ 当搜索文本中的数据时，可使用搜索模式来描述搜索的内容。
+ 正则表达式可以是单字符，或者更复杂的模式。
+ 正则表达式可用于执行所有类型的 **文本搜索** 和 **文本替换** 操作。

#### 语法
```javaScript
/pattern/modifiers;
```
#### 实例
```javaScript
var patt = /chuyuxuan/i;
```
#### 解释
+ ``/chuyuxuan/i`` 是一个正则表达式。
+ `chuyuxuan` 是模式（pattern）（在搜索中使用）。
+ `i` 是修饰符（把搜索修改为大小写不敏感）。

在 JavaScript 中，正则表达式常用于两个字符串方法：`search()` 和 `replace()`。
+ `search()` 方法使用表达式来搜索匹配，然后返回匹配的位置。

#### 实例
+ 使用字符串来执行对 `chuyuxuan` 的搜索：
  ```javaScript
  var str = "Visit chuyuxuan!";
  var n = str.search("chuyuxuan");
```

#### 结果

  ```javaScript
  6
  ```


#### 实例
+ 使用正则表达式执行搜索字符串中`chuyuxuan` 的大小写不敏感的搜索：
```javaScript
  var str = "Visit chuyuxuan";
  var n = str.search(/chuyuxuan/i);
	n 中的结果将是：
	6
```

## replace() 方法返回模式被替换处修改后的字符串。


#### 实例
+ 使用大小写不明的正则表达式以 chuyuxuan 来替换字符串中的 Microsoft：
```javaScript
  var str = "Visit Microsoft!";
  var res = str.replace(/microsoft/i, "chuyuxuan");
	res 的结果将是：
	Visit chuyuxuan!
```

部分修饰符：

|  修饰符 |	描述 |
|:-|:-|
|I	|执行对大小写不敏感的匹配。
|G	|执行全局匹配（查找所有匹配而非在找到第一个匹配后停止）。
|M|	执行多行匹配。

+ 例如：
```javaScript
//在字符串中查找 "ain":
var str="The rain in SPAIN stays mainly in the plain";
var n=str.match(/ain/g);
//n 输出数组结果值:
ain,ain,ain
```
## 正则表达式模式

+ 括号用于查找一定范围的字符串：

| 表达式  | 描述  |
|:-|:-|
|[abc]|	查找方括号之间的任何字符。|	试一试
|[0-9]	|查找任何从 0 至 9 的数字。|	试一试
|(x\|y)	|查找由 \| 分隔的任何选项。|	试一试

+ 元字符（Metacharacter）是拥有特殊含义的字符：

|元字符	|描述	|
|:-|:-|
|\d	|查找数字。|	试一试
|\s	|查找空白字符。|	试一试
|\b	|匹配单词边界。|	试一试
|\uxxxx	|查找以十六进制数 xxxx 规定的 Unicode 字符。|	试一试

+ Quantifiers 定义量词：

|量词	|描述
|:-|:-|
|n+	|匹配任何包含至少一个 n 的字符串。	|试一试
|n*	|匹配任何包含零个或多个 n 的字符串。|	试一试
|n?	|匹配任何包含零个或一个 n 的字符串。|	试一试


### 使用 test()
test() 是一个正则表达式方法。
它通过模式来搜索字符串，然后根据结果返回`` true ``或 `false`。
搜索字符串中的字符 "e"：
```javaScript
var patt = /e/;
patt.test("The best things in life are free!");
//由于字符串中有一个 "e"，以上代码的输出将是：
true
```

### 使用 exec()
exec() 方法是一个正则表达式方法。
它通过指定的模式（pattern）搜索字符串，并返回已找到的文本。
如果未找到匹配，则返回 `null`。
搜索字符串中的字符 "e"：

```javaScript
/e/.exec("The best things in life are free!");
//由于字符串中有一个 "e"，以上代码的输出将是：
e
```

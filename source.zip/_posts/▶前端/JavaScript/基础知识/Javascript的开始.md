---
title: Javascript的部分知识
tags: Javascript
cover: >-
  https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1580367149122&di=deafe93ce2f987df33a87a34c8e685dc&imgtype=0&src=http%3A%2F%2Fstatic.hxrwx.com%2Fupload%2Fmavendemo%2Fcourse%2F20160125%2F1453687219607216305.jpg
categories:
  - ▶前端
date: 2020-01-29 14:48:57
---

# 1.js使用
`<script> 标签`
在 `HTML`中，`JavaScript` 代码必须位于 `<script>` 与 `</script>` 标签之间。

## 实例

```html
<script>
document.getElementById("demo").innerHTML = "我的第一段 JavaScript";
</script>
```

### 内部使用

```HTML
<!DOCTYPE html>
<html>
<head>
  <script>
    function myFunction()
    {
      document.getElementById("demo").innerHTML = "段落被更改。";
    }
  </script>
</head>
<body>
  <h1>一张网页</h1>
  <p id="demo">一个段落</p>
  <button type="button" onclick="myFunction()">试一试</button>
</body>
</html>
```

```html
<html>
<body>
  <h1>A Web Page</h1>
  <p id="demo">一个段落</p>
  <button type="button" onclick="myFunction()">试一试</button>
  <script>
    function myFunction()
    {
      document.getElementById("demo").innerHTML = "段落被更改。";
    }
  </script>
</body>
</html>
````

### 外部使用

外部文件：`myScript.js`

```JavaScript
function myFunction() {
   document.getElementById("demo").innerHTML = "段落被更改。";
}

<script src="myScript.js"></script>
```

# 2.js输出

JavaScript 显示方案
JavaScript 能够以不同方式“显示”数据：
使用 `window.alert()` 写入警告框
  + 使用 `document.write()` 写入 HTML 输出
  + 使用 `innerHTML` 写入 HTML 元素
  + 如需访问 HTML 元素，JavaScript 可使用 `document.getElementById(id)` 方法。
使用 `console.log()`写入浏览器控制台



# 3.js关键词
## JavaScript 关键词
JavaScript 语句常常通过某个关键词来标识需要执行的 JavaScript 动作。
下面的表格列出了一部分将在教程中学到的关键词：

| 关键词 |	描述 |
|:-|:-|
|break|	终止 switch 或循环。|
|continue	|跳出循环并在顶端开始。|
|debugger	|停止执行 JavaScript，并调用调试函数（如果可用）。|
|do ... while	|执行语句块，并在条件为真时重复代码块。|
|for|	标记需被执行的语句块，只要条件为真。|
|function	|声明函数。|
|if ... else|	标记需被执行的语句块，根据某个条件。|
|return	|退出函数。|
|switch	|标记需被执行的语句块，根据不同的情况。|
|try ... catch|	对语句块实现错误处理。|
|var|	声明变量。|

`注释：JavaScript 关键词指的是保留的单词。保留词无法用作变量名。`


值可以是多种类型，比如数值和字符串。

例如，`Bill`+ `Gates`，计算为 `Bill Gates`：


在 JavaScript 中，首字符必须是字母、下划线（-）或美元符号（$）。
连串的字符可以是字母、数字、下划线或美元符号。
提示：数值不可以作为首字符。这样，JavaScript 就能轻松区分标识符和数值。

### JavaScript 对大小写敏感

所有 JavaScript 标识符对大小写敏感。
+ 变量 lastName 和 lastname，是两个不同的变量。

## JavaScript的命名

历史上，程序员曾使用三种把多个单词连接为一个变量名的方法：
+ 连字符：
`first-name`, `last-name`, `master-card`, `inter-city`.
+ *注释：JavaScript 中不能使用连字符。它是为减法预留的。*

+ 下划线：
`first_name`, `last_name`, `master_card`, `inter_city`.

+ 驼峰式大小写（Camel Case）：
`FirstName`, `LastName`, `MasterCard`, `InterCity`.

# 4.js运算符
## javaScript 位运算符
位运算符处理 32 位数。
该运算中的任何数值运算数都会被转换为 32 位的数。结果会被转换回 JavaScript 数。

<!-- | 运算符 | 描述 | 例子 | 等同于 | 结果 | 十进制 |
|:-|:-|:-|:-|:-|:-|:-|
|	&|与|	5 & 1|	0101 & 0001|	0001|	1|
| \| |	或|	5 \| 1	|0101 \| 0001|0101|	5|
|~|	非|	~ 5	|~0101|	1010	|10|
|^	|异或|	5 ^ 1|	0101 ^ 0001|	0100|	4|
|<<|	零填充左位移|	5 << 1|	0101 << 1	|1010	|10|
|>>	|有符号右位移	|5 >> 1	|0101 >> 1|	0010|2|
|>>>	|零填充右位移	|5 >>> 1|	0101 >>> 1|	0010|	2| -->


<table>
  <tr>
    <th>运算符</th>
    <th>描述</th>
    <th>例子</th>
    <th>等同于</th>
    <th>结果</th>
    <th>十进制</th>
  </tr>
  <tr>
    <td>&</td>
    <td>与</td>
    <td>	5 & 1</td>
    <td>	0101 & 0001</td>
    <td>0001</td>
    <td>1</td>
  </tr>
  <tr>
    <td>|</td>
    <td>或</td>
    <td>5 | 1</td>
    <td>0101 | 0001</td>
    <td>0101</td>
    <td>5</td>
  </tr>
  <tr>
    <td>~</td>
    <td>非</td>
    <td>~ 5</td>
    <td>~0101</td>
    <td>1010	</td>
    <td>10</td>
  </tr>
  <tr>
    <td>^</td>
    <td>异或</td>
    <td>5 ^ 1</td>
    <td>0101 ^ 0001</td>
    <td>0100</td>
    <td>4</td>
  </tr>
  <tr>
    <td><<</td>
    <td>零填充左位移</td>
    <td>5 << 1</td>
    <td>0101 << 1</td>
    <td>1010</td>
    <td>10</td>
  </tr>
  <tr>
    <td>>></td>
    <td>有符号右位移</td>
    <td>5 >> 1</td>
    <td>0101 >> 1</td>
    <td>0010</td>
    <td>2</td>
  </tr>
  <tr>
    <td>>>></td>
    <td>零填充右位移</td>
    <td>5 >>> 1</td>
    <td>0101 >>> 1</td>
    <td>0010</td>
    <td>2</td>
  </tr>
</table>

上例使用 4 位无符号的例子。但是 JavaScript 使用 32 位有符号数。
因此，在 JavaScript 中，~ 5 不会返回 10，而是返回 -6。
`~00000000000000000000000000000101 ` 将返回 `11111111111111111111111111111010`。

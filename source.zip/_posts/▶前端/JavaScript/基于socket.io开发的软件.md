---
title: 基于socket.io开发的在线聊天网站
tags:
  - socket.io
  - websocket
  - node.js
cover: https://gitee.com/chuyuxuan/tuc/raw/master/gitee/cover1.jpg
categories:
  - ▶前端
date: 2020-05-26 12:30:00
---
# 一、这里不是在项目介绍
呃。三周前吧，我们的`Internet Web编程`这门课程就结束了，就教一些`Html`、`Css`、`Javascript`等等。嘛，这些自己大一的时候就差不多会了的东西现在学起来可所谓非常轻松。**当然** ，出了这些，还有一些被现在抛弃的技术：`javaweb` 。其实所谓的抛弃嘛就是他并不符合现在的前后端分离的大趋势，当然，代码的`耦合性`也是十分高的。当初html文件里嵌套`<%%>`以及`java`代码可所谓嵌套的自己很烦躁，可想而知，那个还在`jsp`一统天下的年代，程序员要想完成一个企业级的项目得多么痛苦，这种情况下阿里的淘宝能起来真的是很牛逼很牛逼了！👍

当然，自己为了本次课设能稍微有点拿得出手的家伙，就从网络上各种收集资料，各种学习，马马虎虎的敲出来个大概，可能这个项目在一些大佬眼里看来就是一个最基本的小儿科哈哈哈😂.我也就当作一个阶段似的放在[Github](https://github.com/Chuyuxuan0v0/webchat)上面吧，可能多年以后回想起来看看看这个代码也会心里暗自发笑哈哈哈。这个项目花了一周多左右的时间吧，`主要是自己菜的离谱，得慢慢一个一个的学`。像在考虑后端使用`spring BOOT`的时候，那么能不能不用Java去写呀，于是便转到`node.js `上来了，~~Java好久没有去碰了，生疏了🤣。~~ 这点又间接说明了熟能生巧。

# 二、这里是在项目介绍(复制readme)

{%note info %}
## webchat
一款基于`Javascript+express+socket.io`构成的网络在线聊天应用

具体效果可以访问[http://chat.chuyuxuan.xyz:4400](http://chat.chuyuxuan.xyz:4400)   
+ **2020年10月10日前该链接有效，别问为啥，问就是服务器过期我负担不起😭，所以不错的话请给个star吧**


### 项目讲解：

<iframe src="//player.bilibili.com/player.html?aid=840786560&bvid=BV1B54y1D7dA&cid=195091993&page=1" height=600 width=900 scrolling="no" border="0" frameborder="no" framespacing="0" allowfullscreen="true"> </iframe>


## 下载
        git clone https://github.com/Chuyuxuan0v0/webchat.git

## 使用

+ 你需要安装`node.js`,接下来才能进行一下操作，否则会报错误。

        
⭐ 下载后进入根目录
        
        cd ...  \webchat\

⭐ 下载安装`node.js`
        
[点我下载](https://nodejs.org/en/download/)

⭐ 安装`express` ~~项目包里已经集成，安装好node之后可以跳过~~

        npm install express --save

⭐ 安装`socket.io` ~~项目包里已经集成，安装好node之后可以跳过~~

        npm install --save socket.io

        npm install --save socket.io-client


⭐ 安装`mysql` ~~项目包里已经集成，安装好node之后可以跳过~~

        npm install mysql
        
⭐ 在MySQL中导入相关表

        所有要建立的表我都放在express.sql里了，可以根据里面的sql语言自行建立，
        或者借用数据库管理工具例如 navicat 导入该文件进行表的创建。
**注意。我是依赖于mysql 8.0的版本而创建的表格，如果你的sql文件导入不成功，请手动创建表**
表格目录如下:

||||user_info||||
|:-|:-|:-|:-|:-|:-|:-|
|名|类型|长度|小数点|不是null|主键|注释|
|id|int|5|0|√|🔑|注册用户数，注意，要选择自增|
|name|varchar|15|0|√||用户名|
|avatar|varchar|100|0|√||头像路径|
|date|varchar|20|0|√||日期|

||||user_msg||||
|:-|:-|:-|:-|:-|:-|:-|
|名|类型|长度|小数点|不是null|主键|注释|
|id|int|5|0|√|🔑|注意，要选择自增|
|user|varchar|15|0|√||用户名|
|avatar|varchar|100|0|√||头像路径|
|msg|varchar|255|0|√||用户消息|
|date|varchar|20|0|√||日期|


*数据表会不定时更新，详情请看代码里的链接*


⭐ 启动项目

        node app.js

⭐ 在浏览器中输入以下网址 ~~这个端口可以自己更改的~~

        localhost:4400 

## 部分功能展示
+ 1.可以实现在线聊天，发送图片
+ 2.可以是使用`ctrl+Enter`发送消息
+ 3.进入退出有提示
+ 4.适应手机，有响应式布局
+ 5.查看历史聊天记录
+ 6.。。。。。

## 待优化
- 优化UI界面，降低耦合性
- 优化界面响应速度
- 能够私聊个人，一对一聊天
- 。。。。。

## 部分预览

![](cover1.jpg)
![](cover2.jpg)
![](cover3.jpg)

{% endnote %}

# 三、这里是结尾
快6月了，也就几天了，当初的目标正在努力中，真的，只要别放弃就行。加油！
---
title: IEDA配置Tomcat创建web项目
tags:
  - tomcat
  - IDEA
  - Java Web
cover: https://gitee.com/chuyuxuan/tuc/raw/master/Java_web/cover.png
categories:
  - ▶前端
date: 2020-04-15 12:30:00
---
# 吐槽
讲真，要不是学校要求学，我是不会碰`jsp`这项技术的。就类似于[_jQuery_](https://chuyuxuan.xyz/2020/04/06/%E2%96%B6%E5%89%8D%E7%AB%AF/jQuery/jQuery%E5%85%A5%E9%97%A8/)一样。耦合性强，前后端不分离，这些不适合现在了。但听一些前辈们说仍然有一小部分公司还在用这项技术。当然，包括我们学校的官网。不过吐槽归吐槽，学分摆在那里，你不得不去写。什么？不想？不想学还看我这篇文章干嘛~

<img src="https://gitee.com/chuyuxuan/tuc/raw/master/laugh/shakinghead.png"  alt="shakinghead "/>



# 安装
+ 下载[_Tomcat_](https://mirrors.tuna.tsinghua.edu.cn/apache/tomcat/tomcat-9/v9.0.34/bin/apache-tomcat-9.0.34.exe)

这里我是直接外链到`win10`环境直装的`tomcat 9.0`，如果你使用的是`MacOS`或者`Linux`。稍微抱歉一下。


{% note danger %}

注意，安装路径请确保你有足够的权限访问，否则后面会出现环境运行无权限。<font style="font-weight:bold;color:red;">建议默认安装在C盘。</font>

{% endnote %}

具体安装步骤我这里就不给出了，可以自行[_Google_](https://www.google.com)。唯一要注意一点的是端口号没有特别的需求默认`8080`端口即可。

# 配置

+ 我的IEDA版本是2019.1.3

1. 打开`IEDA`，新建一个`空项目`。并且给命名。

![](https://gitee.com/chuyuxuan/tuc/raw/master/Java_web/1.gif)

2. 创建好了JavaWeb项目要配置一下文件夹路径，首先在`web/WEB-INF`文件夹下面创建两个文件夹：`class`和`lib`.`class`用来存放编译后输出的`classes`文件，`lib`用于存放第三方的`jar`包。

![](https://gitee.com/chuyuxuan/tuc/raw/master/Java_web/2.gif)

3. `File`=>`Project Structure`=>`Module`=>`Paths `=>`Use module compile output path` ，点击后面的`...`将`Output path`和`Test output path`都选择刚刚创建的`class`文件夹,点击`Apply`。

![](https://gitee.com/chuyuxuan/tuc/raw/master/Java_web/3.gif)

4. 接着选择`Dependencies` ,将`Module SDK`选择为自己的`JDK`. 点击右边的`“+”`号 ,选择` Jars or Directories`。配置到刚刚创建好的`lib`文件中。

![](https://gitee.com/chuyuxuan/tuc/raw/master/Java_web/4.gif)

5. 打开菜单`Run` 选择`Edit Configuration `也可以点击右上方的往下的三角旁边的白框框选择`Edit Configuration`,点击`“+”`号选择`Tomcat Server`,选择`Local`。在`Name`处创建`Tomcat`名字，点击`Application server`后面的`Configure...`，弹出`Tomcat Server`窗口，选择本地安装的`Tomcat`文件路径. 设置`HTTP port`和`JMX port`（默认值即可），点击 `Apply`.

![](https://gitee.com/chuyuxuan/tuc/raw/master/Java_web/5.gif)

6. 至此Tomcat配置完成。 下一步在Tomcat中部署并运行项目 `Run` , `Edit Configurations`，进入`Run/Debug Configurations`窗口 ,选择刚刚建立的Tomcat容器,选择`Deployment`,点击右边的`“+”`号 ,选择`Artifact`,选择`web`项目,`Application contex`填一个名字。注意，tomcat的路径需要手动在`startup/Connection`中配置好。

![](https://gitee.com/chuyuxuan/tuc/raw/master/Java_web/6.gif)

# 运行

7. 好啦！来运行项目看看！选择`index.jsp`，修改里面的代码内容，嘻嘻！成功运行！

![](https://gitee.com/chuyuxuan/tuc/raw/master/Java_web/7.gif)


# 问题（可能出现）
{% note danger %}

注意，若出现：`Error running 'Tomcat 8.5.45': port out of range:-1 && 淇℃伅 [main] org.apache.catalina`。

+ 请在`tomcat`安装目录下进入`conf/server.xml` ，把里面的`sever port = "-1"`改成1028（大于1024不等于8080即可）。

+ 修改logging.properties 文件里面的`java.util.logging.ConsoleHandler.encoding = UTF-8`为`java.util.logging.ConsoleHandler.encoding = GBK`

{% endnote %}
---
title: Vue小基础大集合
tag:
  - Vue
categories:
  - ▶前端
cover: 'https://gitee.com/chuyuxuan/tuc/raw/master/Vue/vue_cover.png'
---
# 挂载

**在写Vue之前，要引入`Vue.js`,除了下载下来，还可以使用官方的CDN加速的Vue.js:**
        
```js
//开发环境版本，包含了有帮助的命令行警告 
<script src="https://cdn.jsdelivr.net/npm/vue/dist/vue.js"></script>
```
**整体格式如下**


```html
<!DOCTYPE html>
<html lang="cn">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vue</title>
    <!-- 开发环境版本，包含了有帮助的命令行警告 -->
    <script src="https://cdn.jsdelivr.net/npm/vue/dist/vue.js"></script>
</head>

<body>
   
    <div id="tup"> 
    
    
    </div>
        
   
    <script>
        var app = new Vue({
            el: '#tup',//所挂载的容器ID
            data: {
                        //填写容器数据
            },
            methods: {
                A: function () {  },
                B: function () {  }  //可执行函数
            },
        })
    </script>
</body>

</html>
```

# V-on 事件绑定

### **可以用 `@`来代替 `v-on`，快速绑定一般是把`函数`与操作标签绑定。**

```html
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vue</title>
    <!-- 开发环境版本，包含了有帮助的命令行警告 -->
    <script src="https://cdn.jsdelivr.net/npm/vue/dist/vue.js"></script>
</head>
<style>
    body {
        background-color: rgb(15, 16, 68);
        color: white;
    }

    #jian {
       color: rgb(29, 207, 73);
    }

    #jia {
        color: rgb(29, 207, 73);
    }
</style>

<body>
    <div id="bar">
        <input id="jian" value="减" @click="add">       
        <div id="show">
            <span>{{num}}</span>
        </div>
        <input id="jia" value="加" @click="sub">  
    </div>
    <script>
        var app = new Vue({
            el: '#bar',
            data: {
                num: 28,
            },
            methods: {
                add: function () {
                    console.log("add");
                    this.num ++;
                },
                sub: function () {
                    console.log("sub");
                    this.num --;
                }
            },
        })
    </script>
</body>

</html>
```
![1](https://gitee.com/chuyuxuan/tuc/raw/master/Vue/v-on1.png)
![2](https://gitee.com/chuyuxuan/tuc/raw/master/Vue/v-on2.png)

# V-text 值
###　**在`双标签`中，除了在标签内添加`v-text`外，还可以用`插值表达式`：`{{ text }}`来代替数据。**
![3](https://gitee.com/chuyuxuan/tuc/raw/master/Vue/v-text1.png)
![4](https://gitee.com/chuyuxuan/tuc/raw/master/Vue/v-text2.png)
![5](https://gitee.com/chuyuxuan/tuc/raw/master/Vue/v-text3.png)

# V-html 
### **说到 `v-text` 就不得不说到 `v-html` ，这两个是相辅相成的，在一些值中，有html的标签，用 `v-html` 会解析，而 `v-text` 不会解析.**

![6](https://gitee.com/chuyuxuan/tuc/raw/master/Vue/v-html1.png)

# V-show 
### **扯到`v-show`就得说说他和`v-if `的藕断丝连了.不过这里先说下 `v-show`.**
**顾名思义就是让数据展示，那么它的值就是`布尔格式`的。**
![7](https://gitee.com/chuyuxuan/tuc/raw/master/Vue/v-show1.png)

### 在 **_DOM树_** 里，`v-show`不会让元素直接从DOM中消失，而是将其隐藏，相对于 `v-for` 直接操纵 **_DOM树_** ，它对内存的消耗是少的。

# V-for 
### 这里就直接上图，看看 **_DOM树_** 的一些对比。
![7](https://gitee.com/chuyuxuan/tuc/raw/master/Vue/v-if1.png)

# V-bind 单向数据绑定
### **顾名思义，还有一个双向数据绑定的家伙。v-bind后面是` ：属性名=`，绑定之后，这个属性对应的值要去vue的data中找。除了url，还可以绑定图片src属性、超链接的class.**

```javascript
var app = new Vue({
    el:'.app',
    data:{
        url:"https://www.baidu.com",
    }
});
```
```html
<div class="app">
    <a v-bind:href="url">click</a>
</div>  
 <!-- v-bind 可缩写成冒号，例如下面 -->
 <div class="app">
    <a :href="url">click</a>
</div>
```
![8](https://gitee.com/chuyuxuan/tuc/raw/master/Vue/v-bind1.png)
![9](https://gitee.com/chuyuxuan/tuc/raw/master/Vue/v-bind2.png)

# V-molde 数据双向绑定
### vue中经常使用到`input`和`textarea`这类表单元素，使用v-model实现这些标签数据的双向绑定，它会根据控件类型自动选取正确的方法来更新元素。V-molde其实是[语法糖](https://baike.baidu.com/item/%E8%AF%AD%E6%B3%95%E7%B3%96/5247005?fr=aladdin).

```html
<template>
    <div>
        <input type="text" placeholder="请输入姓名" v-model="name"/>
    </div>
</template>

<script>
    export default {
        data() {
            return {
                name: ''
            }
        }
    }
</script>
```
### 讲大白话的一点，就是同步更新，vue从它的数组里拿东西，然后用户输入的东西同样会存入到数组中，会改变数组里面的值。浏览器又会把数组里的值同步渲染到页面中。这里附上一个小的demo。当然，也会用到`V-for`的指令。待会儿再来一起呈现。

# V-for 迭代
### 本质上就是for循环，在Vue中可以方便的把数据给列举取出来，用在数组上用的最多。`v-for`基本语法为：

        （item,index）in 'data'
        //这里item表示每一项，index表示索引。具体看下列代码：

注：只是实现了基本功能，对页面并没有写太多的css.

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vue-for</title>
    <!-- 开发环境版本，包含了有帮助的命令行警告 -->
    <script src="https://cdn.jsdelivr.net/npm/vue/dist/vue.js"></script>
</head>
<body>
    <div id="app">
        <button type="button" @click="add" >baba</button>
        <button type="button" @click="remove" >ddd</button>
        <ul>
            <li v-for="(item,index) in arr">
                {{item}} address:{{index}}
            </li>
        </ul>
        <h1 v-for="item in vegetables" :title="item.name">
<!-- 这里就是把值给循环列举出来 -->
            {{item.name}}
        </h1>
    </div>
    <script>
        var app = new Vue({
            el: "#app",
            data: {
                arr: ["beijing", "shenzheng", "aomeng", "changsha"],
//这里是循环的数组
                vegetables: [{
                        name: "i am handsome!"
                    },
                    {
                        name: "some one like my handsome!"
                    }
                ]
            },
            methods: {
                add: function () {
                    this.vegetables.push({
                        name: "wo shi ni baba !"//push 推入到vegetable数组
                    });
                },
                remove: function () {
                    this.vegetables.shift();//shift 从vegetable数组移除
                }
            },
        })
    </script>
</body>
</html>

```

# 阶段小结
这里写了一个综合上面的所有要点的小demo.一个记事本。

```html
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Notepad</title>
    <!-- 开发环境版本，包含了有帮助的命令行警告 -->
    <script src="https://cdn.jsdelivr.net/npm/vue/dist/vue.js"></script>
    <style>
        body {
            background: rgb(119, 201, 221);
        }

        #big_conntent {
            height: 500px;
            width: 500px;
            background: rgb(119, 201, 221);
            color: white;
            text-align: center;
            margin: 0 auto;
            /*居中元素*/
        }

        #item {
            float: left;
        }

        #input {
            width: 500px;
            height: 40px;
            font-size: 20px;
            border-radius: 20px;
        }
    </style>

</head>

<body>

    <div id="big_conntent">
        <div id="title">
            <h1>NOTEPAD</h1>
        </div>
        <div id="conntent">
            <input id="input" @keyup.enter="add" v-model="inputV" placeholder="Please input">
            
        </div>
        <div id="show">
            <div id="item">
                <ol>
                    <li v-for="(item,index) in list">
                        {{item}}
                        <button id="disdroy" @click="remove(index)">X</button>
                    </li>
                </ol>
                
            </div>
            <button @click="add">确认添加</button>
            <h3>共有{{list.length}}个数据</h3>
            <button @click="clear">一键清空</button>
        </div>
    </div>
    <script>
        var app = new Vue({
            el: "#big_conntent",
            data: {
                list: ["eating!", "sleeping!", "laugthing!", "playing!"],
                inputV: "    I'm your father!"
            },
            methods: {
                add: function () {
                    this.list.push(this.inputV);
                    console.log(this.inputV)
                },
                remove:function(index){
console.log("Delete click");
console.log(index);
this.list.splice(index,1);
                },
                clear:function()
                {
                    this.list=[];
                },
            },
        })
    </script>
</body>

</html>
```

---
title: Linux 安装 nginx
tags:
  - Linux
  - centOS
  - nginx
cover: 'https://gitee.com/chuyuxuan/tuc/raw/master/linux/122.jpg'
categories:
  - ▶后端
date: 2020-05-15 08:08:08
---
# 手把手教你把自己的静态项目部署到服务器上

自己写数学作业写的是在是烦躁，干脆找个东西来`放松`以下,于是就出了这期视频。
y
+ 视频地址：[BV1Ha4y1e72M](https://www.bilibili.com/video/BV1Ha4y1e72M)

+ 视频中的网站：[Video.chuyuxuan.xyz](http://video.chuyuxuan.xyz/) `有小彩蛋哦！`

<iframe src="//player.bilibili.com/player.html?aid=668236157&bvid=BV1Ha4y1e72M&cid=191086854&page=1" height=600 width=900 scrolling="no" border="0" frameborder="no" framespacing="0" allowfullscreen="true"> </iframe>

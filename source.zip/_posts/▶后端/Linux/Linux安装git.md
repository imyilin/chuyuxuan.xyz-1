---
title: 为了博客也是操碎了心（Linux 下 配置 git ）
tags:
  - Linux
  - centOS
cover: 'https://gitee.com/chuyuxuan/tuc/raw/master/linux/linux_cover.jpg'
categories:
  - ▶后端
date: 2020-02-28 18:49:35
---
# 起因
诚然,我的博客采用的是`hexo farmework`，依托于`gitpage`而搭建的，对于国内的我来说很不友好。😖于是我在想啊，要不用CND加速？**哈哈哈，蛮不错的**。结果一查相关资料，顿时有点懵。
+ 我买了域名，但是`gitpage`依赖于GitHub，是属于国外的服务器的，所以我并不需要备案就可以用[chuyuxuan.xyz](https://chuyuxuan.xyz)来访问我的博客。

+ 而假如我想用国内的CDN加速我的资源，我的域名就必须要备案。备案你就得必须要有服务器。
![](https://gitee.com/chuyuxuan/tuc/raw/master/laugh/005.gif)

好了，扯的有点远了，总之，能用技术解决的事情尽量用技术去解决。所以了了适应云主机，这里便采用虚拟机模拟了一个本地的服务器，为自己把博客部署到云端做准备。
# 准备
{% note success %}
1. VMware Workstation [点击下载](https://my.vmware.com/en/web/vmware/info/slug/desktop_end_user_computing/vmware_workstation_pro/15_0?wd=&eqid=9718f2bc000e9110000000065e58f46d)
2. CentOS ISO [点击下载](https://mirrors.aliyun.com/centos/7/isos/x86_64/CentOS-7-x86_64-DVD-1908.iso)

*当然，可以自己百度搜索相关资源*
{% endnote %}

# 安装 `VMware` 和 建立`centOS`虚拟机
这里我就不再演示了，是个人就会安装，实在不会百度。
![](https://gitee.com/chuyuxuan/tuc/raw/master/laugh/097.gif)

# git服务端安装
## 从`yum`安装git

    yum install git-core

## 在需要的位置创建一个裸仓库

    cd /usr/local 
    mkdir git
    cd git
    git init --bare demo.git

## 创建一个git用户并赋予密码

    useradd git
    passwd git//输入密码大于8位，用于push和clone

## 赋予git用户权限
`chown`将指定文件的拥有者改为指定的用户或组，用户可以是用户名或者用户ID；组可以是组名或者组ID；文件是以空格分开的要改变权限的文件列表，支持通配符。系统管理员经常使用chown命令，在将文件拷贝到另一个用户的名录下之后，让用户拥有使用该文件的权限。

    chown -R git:git demo.git //把权限赋给名字为git的用户

## 禁用git用户shell登录（为了安全，虽然我是在本地虚拟机上跑）

    vim /etc/passwd
    //找到最后一行（一般都是的）
    // 敲 “i” 进行编辑
    git:x:1000:1000::/home/git:/usr/bin/git-shell
    //改成上面格式之后esc然后敲“：wq!”保存并退出

**恭喜!服务端配置基本完成，接下来是客户端了。**
# git客户端安装

**这里百度去吧，很简单的，我采用的是window下的git服务，就直接下一步好了，这里给出下载地址：**[点击下载](https://git-scm.com/downloads)

## 创建客户端用户
安装好后桌面右键，`git Bush here`就可以进入shell.

    git config --global user.name "你的名字"
    git config --global user.email "你的邮箱"
## 创建密钥ssh(不嫌麻烦的话可以不用配置)

    ssh-keygen -t rsa -C "你的邮箱"
然后**一直回车**，直到完毕。

## 将公钥加入服务器列表

### 取得本地ssh公钥

    cd ~/.ssh
    cat id_rsa.pub 

复制，内容大概如下：
```git
ssh-rsafdjslafhs;jgjieghegoghskf+fdhsjaklghj
fsahjgjrl;agjkfl;dafjsighiroghuerhgkfdvrreui
fhgrjegreoughuighuitglsghruighirhgbibvifrggg
grhuipaghuireghergerpreofjeiwfhfuhbjzb+0frhf
fshgheagwgegw======你的邮箱
```
### 添加到服务端

默认列表在/root/.ssh/authorized_keys，使用vim 编辑此文件输入刚才复制的内容，保存退出。

    vi /root/.ssh/authorized_keys
    //i修改
    //esc后输入:wq保存退出

# 克隆远程项目到本地

在自己的电脑上随便找个位置，`git Bush here`，

    git clone git@‘你服务器的IP地址’:/usr/local/git/demogit.git
    
    //例如： git clone git@111.111.111.111:/usr/local/git/demo.git


# 至此，over。

当然，你可以push你自己的代码到服务器上，比方说把`hexo`静态博客push上去，实现本地访问。

# 感慨

花了我很久时间，大部分时间我在做无用功。。怪自己自学太慢了。
![](https://gitee.com/chuyuxuan/tuc/raw/master/laugh/087.gif)

我在想自己还到底要不要用CDN加速哦。。。难搞难搞。。
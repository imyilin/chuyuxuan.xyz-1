---
title: 日志的自动分类插件
tags: hexo-auto-category
cover: 'https://gitee.com/chuyuxuan/tuc/raw/master/hexo_auto_category/4.png'
categories:
  - ▶小技能
date: 2020-02-08 21:00:00
---
# 简介
---
Hexo写日志，通常我们都需要维护一个front-matter信息，包括title、date。博客多了，为了方便日志分类，一般还需要设置categories。
比如下面的例子：

![分组1](https://gitee.com/chuyuxuan/tuc/raw/master/hexo_auto_category/2.png)

这样就会导致文章特别多而且繁杂，不好整理：
![分组2](https://gitee.com/chuyuxuan/tuc/raw/master/hexo_auto_category/1.png)
久而久之，就会发现很多问题：
+ 工作繁琐：大量的category是重复性工作
+ 容易出错：大小写和中英文目录有可能混杂。比如有个web目录，偶尔我们写成了Web，造成了目录树中冗余的节点。
+ 可维护性差：如果要更改目录树中的节点，就要手动更改每个日志的categories变量。

**所以，这里介绍一个可以让我们文章``自动生成category``插件[ hexo-auto-category](https://github.com/xu-song/hexo-auto-category)，实现自动分类**

# 自动生成 `categories`
---
最常用的文件管理策略，就是利用文件系统目录结构(树形结构 directory-tree)。
同样，为了便于管理大量的日志文件，采用目录结构是一种简便可行的方案。hexo-auto-category根据日志文件(Markdown)所在文件目录自动分类，即自动生成`markdown`的`front-matter`中categories变量。
## 示例

对于博客 `source/_post/web/framework/hexo.md`，该插件会自动生成以下categories:
```yml
categories:
  - web
  - framework
```
# 安装
---
采用`npm`安装：
```yml
$ npm install hexo-auto-category --save
```
![分组3](https://gitee.com/chuyuxuan/tuc/raw/master/hexo_auto_category/3.png)

# 配置
---
 在站点根目录下的_config.yml添加：

```yml
# Generate categories from directory-tree
# Dependencies: https://github.com/xu-song/hexo-auto-category
# depth: the depth of directory-tree you want to generate, should > 0
auto_category:
 enable: true
 depth:
```
如果只想生成第一级目录分类，可以设置depth属性，比如：
```yml
auto_category:
 enable: true
 depth: 1
 ```
# 编译 & 部署
---
```yml
$ hexo clean ; hexo generate ; hexo deploy
```
大功告成！享受吧！

---
title: Atom插件离线安装
tags:
  - atom
  - 插件
cover: >-
  https://gss0.bdstatic.com/94o3dSag_xI4khGkpoWK1HF6hhy/baike/c0%3Dbaike180%2C5%2C5%2C180%2C60/sign=9c098eafe0cd7b89fd6132d16e4d29c2/728da9773912b31bf85f434c8018367adab4e1a0.jpg
categories:
  - ▶小技能
date: 2020-02-01 09:22:31
---
# 前言：你电脑必须要有node.js，并且关闭atom进行安装

# 1.在atom install界面输入要安装的插件名字![在这里插入图片描述](https://img-blog.csdnimg.cn/20200201131337658.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L0NyeXVfeHVhbg==,size_16,color_FFFFFF,t_70)
# 2.点击想要的包，进入到它的网页，点击license跳转到github仓库。
![在这里插入图片描述](https://img-blog.csdnimg.cn/20200201131627903.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L0NyeXVfeHVhbg==,size_16,color_FFFFFF,t_70)
# 3.进入仓库
![在这里插入图片描述](https://img-blog.csdnimg.cn/20200201131845199.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L0NyeXVfeHVhbg==,size_16,color_FFFFFF,t_70)
# 4.Git clone 或者下载
![在这里插入图片描述](https://img-blog.csdnimg.cn/20200201131921811.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L0NyeXVfeHVhbg==,size_16,color_FFFFFF,t_70)
### 我这里用git工具把他下载到atom的package目录中，当然，你直接下载丢到这个目录也可以。记得解压嗷！
![在这里插入图片描述](https://img-blog.csdnimg.cn/20200201132114851.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L0NyeXVfeHVhbg==,size_16,color_FFFFFF,t_70)
# 5.在该目录下打开CMD，执行`npm install `命令进行安装
#### ***注意，你需要安装node.js!  并且此时atom是关闭状态！***
![在这里插入图片描述](https://img-blog.csdnimg.cn/20200201132431770.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L0NyeXVfeHVhbg==,size_16,color_FFFFFF,t_70)
# 好了，大功告成！尽情享用吧！
![在这里插入图片描述](https://img-blog.csdnimg.cn/20200201132859141.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L0NyeXVfeHVhbg==,size_16,color_FFFFFF,t_70)

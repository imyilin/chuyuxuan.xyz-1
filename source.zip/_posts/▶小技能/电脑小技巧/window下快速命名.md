---
title: Window下照片快速批量命名
tag:
  - windows
  - cmd
  - bat
categories:
  - ▶小技能
cover: 'https://gitee.com/chuyuxuan/tuc/raw/master/Computer_Graphics/logos.jpg'
date: 2020-03-05 13:16:38
---
**1、新建立一个文件夹，往里面丢入需要命名的照片（一般我都是这个需求）。**
**2、新建一个txt文本，输入：**



```shell
@echo off
set a=0
setlocal EnableDelayedExpansion
for %%n in (*.png) do (
set /A a+=1
ren "%%n" "!a!.png"
)

```
其中` ren "%%n" "!a!.png"` 为关键代码，`ren A B ` 把A命名给B。

**注意，不要改变源码里的除了后缀名之外的任何东西，否则会出问题。**







# 以下为代码解析


至于`setlocal enabledelayedexpansion`"延迟环境变量扩展".

        set var=test
        echo %var%
    
给var赋值为test,用test把%var%这个变量名替换,这是`环境变量扩展`.

`延迟环境变量扩展`:CMD在解释命令时,首先会把一条完整的命令进行读取,然后进行匹配操作,匹配时他会把命令里的变量用变量的值个替换掉,然后执行这个替换好的命令.问题就出在"一条完整的命令",在BAT中,IF FOR这样的命令都可以加括号,将一些命令嵌套在里面执行.

这样的话对于一条可以加扩号嵌其他命令的命令,他的完整格式就是
for %%i in (....)这样一个整体.此时,如果我们如果在括号里面嵌入一些设置变量值的命令,就会出现问题了!


        @echo off
        for /l %%i in (1,1,5) do (
            set var=%%i
            echo %var%
        )
    
按理说执行结果应该是

        1
        2
        3
        4
        5

但执行后却显示5个空行的错误提示!为什么?根据我们上面说的知识来理解
        
        @echo off
        set var=test
        for /l %%i in (1,1,5) do (
            set var=%%i
            echo %var%
        )
这个就会打印5个test了，说明`for /l %%i in (1,1,5) `没有起作用。
 
通过这两个例子,大家因该已经理解,如果只有环境变量扩展这个过程的话,如果我们在可以嵌套命令的命令中执行赋值操作时,会让我们的BAT出现给变量赋值的问题.那么这个时候"延迟环境变量扩展",这个概念就被提出来了
在批处理中,我们可以用`setloacl ENABLEDELAYEDEXPANSION`这个命令来启用"延迟环境变量扩展" 在我们启用了"延迟环境变量扩展"后,当CMD在解释涵有嵌套格式的命令时,他会把嵌套的命令一条一条的先执行一次,然后再进行匹配操作,这样我们的赋值操作就会完成.并且再"延迟环境变量扩展"启用后,CMD会用!号来判断这是不是一个变量,如没启用来变量 用%name%这样的格式判断,启用后就用!name!这样的格式判断了,这个符号我们需要注意!
例子:
        
        @echo off
        setlocal ENABLEDELAYEDEXPANSION
        set var=test
        for /l %%i in (1,1,5) do (
            set var=%%i
            echo !var!
        )
执行结果应该是
        
        1
        2
        3
        4
        5


这样大家因该明白什么是延迟环境变量扩展了吧.
再来一个例子

        @echo off
        set var=test & echo %test%
        pause

这条命令放在一行,表示他是一条完整的命令,不启用"延迟环境变量扩展",就会出现上面的赋值错误!改成这样
        
        @echo off
        setlocal ENABLEDELAYEDEXPANSION
        set var=test & echo !var!
        pause
        
很容易理解了吧!
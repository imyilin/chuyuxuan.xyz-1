---
title: 8分钟让你了解CDMA码分多址
tags:
  - CDMA码分多址
  - 计算机网络
cover: 'https://gitee.com/chuyuxuan/images_bed/raw/master/w_CDMA.jpg'
categories:
  - ▶计算机网络
date: 2020-02-04 12:42:53
---
## CDMA码分多址
<iframe src="//player.bilibili.com/player.html?aid=82009656&cid=140329662&page=1" height=600 width=900 scrolling="no" border="0" frameborder="no" framespacing="0" allowfullscreen="true"> </iframe>

#### 以下来自[百度百科](https://baike.baidu.com/item/%E7%A0%81%E5%88%86%E5%A4%9A%E5%9D%80/2503754?fromtitle=CDMA&fromid=185961&fr=aladdin)：
码分多址是指利用码序列相关性实现的多址通信 。码分多址(CDMA)的基本思想是靠不同的地址码来区分的地址。每个配有不同的地址码，用户所发射的载波(为同一载波)既受基带数字信号调制，又受地址码调制，接收时，只有确知其配给地址码的接收机，才能解调出相应的基带信号，而其他接收机因地址码不同，无法解调出信号。划分是根据码型结构不同来实现和识别的。一般选择伪随机码(PN码)作地址码。由于PN码的码元宽度远小于PCM信号码元宽度(通常为整数倍)，这就使得加了伪随机码的信号频谱远大于原基带信号的频谱，因此，码分多址也称为扩频多址 。

---
title: 5分钟让你明白CRC循环冗余校验
tags:
  - CRC循环冗余校验
  - 计算机网络
cover: 'https://gitee.com/chuyuxuan/images_bed/raw/master/w_CRC.jpg'
categories:
  - ▶计算机网络
date: 2020-02-04 12:42:57
---
## CRC循环冗余校验
<iframe src="//player.bilibili.com/player.html?aid=82377367&cid=140943350&page=1" height=600 width=900 scrolling="no" border="0" frameborder="no" framespacing="0" allowfullscreen="true"> </iframe>

#### 以下来自[百度百科](https://baike.baidu.com/item/CRC/1453359?fr=aladdin):
- 循环冗余校验（Cyclic Redundancy Check， CRC）是一种根据网络数据包或计算机文件等数据产生简短固定位数校验码的一种信道编码技术，主要用来检测或校验数据传输或者保存后可能出现的错误。它是利用除法及余数的原理来作错误侦测的。

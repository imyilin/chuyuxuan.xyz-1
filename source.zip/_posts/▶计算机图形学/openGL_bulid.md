---
title: OpenGL 在Win下开发环境配置
tag:
  - openGL
  - Visual studio 2019
cover: 'https://gitee.com/chuyuxuan/tuc/raw/master/Computer_Graphics/cmds.jpg'
categories:
  - ▶计算机图形学
---
配着玩意儿确实挺麻烦的。按着[_`官方文档`_](https://learnopengl-cn.github.io/01%20Getting%20started/02%20Creating%20a%20window/)的步骤一步一步地踩了过去。当然，这里也借鉴了几位大佬的指点，终于把环境给配置好了。

# 环境介绍

+ [Window 10](https://www.microsoft.com/zh-cn/software-download/windows10)
+ [Visual Studio 2019](https://visualstudio.microsoft.com/zh-hans/downloads/)
+ [GLFW](http://www.glfw.org/download.html) 
+ [GLAD](http://glad.dav1d.de/) 
+ [CMake](https://cmake.org/download/) 

# 下载并编译GlFW库
{% note success  %}
## 1.把[CMake](https://cmake.org/download/) 和[GLFW](http://www.glfw.org/download.html) 下载到本地，并且把`CMake`安装好。安装就平时安装OK。

## 2.解压`GlFW`。
![](https://gitee.com/chuyuxuan/tuc/raw/master/Computer_Graphics/2020030301.png)

## 3.打开`CMake`，设置`source code`为`GLFW`解压目录，`build`目录为`GLFW`解压目录下新建的`build`文件夹。
![](https://gitee.com/chuyuxuan/tuc/raw/master/Computer_Graphics/2020030302.png)
## 4.`Configure`，后面的值默认即可。
![](https://gitee.com/chuyuxuan/tuc/raw/master/Computer_Graphics/2020030303.png)
## 5.然后再次点击`Configure`，并且`Generate`。
![](https://gitee.com/chuyuxuan/tuc/raw/master/Computer_Graphics/2020030301.gif)
## 6.完成后，在`build`目录下生成了`Visual Studio的解决方案`，打开即可。
![](https://gitee.com/chuyuxuan/tuc/raw/master/Computer_Graphics/2020030305.png)
![](https://gitee.com/chuyuxuan/tuc/raw/master/Computer_Graphics/2020030306.png)

## 7.这时在`visual Studio` 的`build\src\Debug\`目录下，得到了编译好的`glfw3.lib`库文件，我们把它放好，留在后面备用。
![](https://gitee.com/chuyuxuan/tuc/raw/master/Computer_Graphics/2020030307.png)

{% endnote %}

# 下载`glad`库。

{% note info %}

在浏览器中打开[Glad在线服务页面](http://glad.dav1d.de/) ,修改语言为`C/C++`，选择`OpenGL`，API选择使用的对应OpenGL版本(官方推荐3.3以上的)，Profile选择`Core`，勾上`Generate a loader`，点击`GENERATE`，在跳转后的界面里下载压缩好的`glad`即可。
![](https://gitee.com/chuyuxuan/tuc/raw/master/Computer_Graphics/2020030302.gif)

{% endnote %}
# 配置Visual Studio工程
1.建立一个新的目录，里面包含Libs和Include文件夹，将GLFW源码中的include\文件下的内容、GLFW编译后的库、下载的GLAD库，放入该新建好的目录内，这样方便以后工程可以复用。这里提供建立好的文件[下载](https://gitee.com/chuyuxuan/blog/raw/master/homeworks/openGL.zip)，不过是否适配你的电脑就不好说了。配置项目如下所示。
![](https://gitee.com/chuyuxuan/tuc/raw/master/Computer_Graphics/2020030308.png)
2. Visual Studio 新建一个工程，把上一步的配置好的目录放进去。（图中的`openGL`为**上一步**所创建的目录名，其实也可以不放，只要在后期编译时，引入真确的路径即可。）
![](https://gitee.com/chuyuxuan/tuc/raw/master/Computer_Graphics/2020030309.png)

3.配置Visual studio 新工程，**注意文件路径以及文件名称**。

![](https://gitee.com/chuyuxuan/tuc/raw/master/Computer_Graphics/2020030310.png)
![](https://gitee.com/chuyuxuan/tuc/raw/master/Computer_Graphics/2020030312.png)
![](https://gitee.com/chuyuxuan/tuc/raw/master/Computer_Graphics/2020030313.png)
![](https://gitee.com/chuyuxuan/tuc/raw/master/Computer_Graphics/2020030314.png)

4.添加`opengl\src\glad.c`源文件。
![](https://gitee.com/chuyuxuan/tuc/raw/master/Computer_Graphics/2020030303.gif)

5.编译代码并进行测试。
源码如下：
```cpp
#include <glad/glad.h>
#include <GLFW/glfw3.h>
#include <iostream>
using namespace std;

void framebuffer_size_callback(GLFWwindow* window, int width, int height);

int main() {
    glfwInit();
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

    GLFWwindow *window = glfwCreateWindow(800, 600, "LearnOpenGL", NULL, NULL);
    if (window == NULL) {
        cout << "Failed to create GLFW window" << endl;
        glfwTerminate();
        return -1;
    }
    glfwMakeContextCurrent(window);

    if (!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress)) {
        std::cout << "Failed to initialize GLAD" << std::endl;
        return -1;
    }

    glViewport(0, 0, 800, 600);

    glfwSetFramebufferSizeCallback(window, framebuffer_size_callback);

    while (!glfwWindowShouldClose(window)) {
        glfwSwapBuffers(window);
        glfwPollEvents();
    }

    glfwTerminate();
    return 0;
}

void framebuffer_size_callback(GLFWwindow* window, int width, int height) {
    glViewport(0, 0, width, height);
}
```

运行结果如下所示。
![](https://gitee.com/chuyuxuan/tuc/raw/master/Computer_Graphics/2020030304.gif)


# 好啦！大功告成，接下来就开始愉快的写作业吧！